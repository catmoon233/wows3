package net.mcreator.wows.procedures;

public class SxxlzlcProcedure {
	public static void execute() {
	}
}
