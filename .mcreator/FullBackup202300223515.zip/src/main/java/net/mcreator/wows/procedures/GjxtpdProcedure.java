package net.mcreator.wows.procedures;

public class GjxtpdProcedure {
	public static void execute() {
	}
}
