package net.mcreator.wows.procedures;

public class Backpack1Procedure {
	public static void execute() {
	}
}
