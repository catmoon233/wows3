package net.mcreator.wows.procedures;

import net.minecraft.world.entity.Entity;
import net.mcreator.wows.network.WowsModVariables;

public class UiZhiShuZhixueliangProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		
		WowsModVariables.PlayerVariables playerVariables = entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables());
		
		double playerhp2 = playerVariables.playerhp2;
		double playermaxhp2 = playerVariables.playermaxhp2;
		double smts = playerVariables.smts;

		String wb = String.format("%.0f/%.0f", playerhp2, playermaxhp2 * (1 + smts));
		return wb;
	}
}
