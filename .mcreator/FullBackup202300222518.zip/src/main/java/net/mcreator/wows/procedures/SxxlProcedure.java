package net.mcreator.wows.procedures;

public class SxxlProcedure {
	public static void execute() {
	}
}
