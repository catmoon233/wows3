package net.mcreator.wows.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.wows.network.WowsModVariables;

public class EuiZhiShuZhixiulianProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		return "\u5F53\u524D\u4FEE\u70BC\u5883\u754C:" + (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).lever;
	}
}
