package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.wows.network.WowsModVariables;
import net.mcreator.wows.WowsMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Smhf2Procedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity().level, event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("smhf") > 0) {
			if (entity.getPersistentData().getDouble("smhf23") == 0) {
				entity.getPersistentData().putDouble("smhf2", 1);
			}
			if (entity.getPersistentData().getDouble("smhf2") == 1) {
				entity.getPersistentData().putDouble("smhf23", 1);
				entity.getPersistentData().putDouble("smhf2", 0);
				WowsMod.queueServerWork(20, () -> {
					if (entity.getPersistentData().getDouble("healthnow1") < entity.getPersistentData().getDouble("healthmax")) {
						entity.getPersistentData().putDouble("healthnow1", (entity.getPersistentData().getDouble("healthnow1") + entity.getPersistentData().getDouble("smhf") / 2));
					}
					if (entity.getPersistentData().getDouble("llnow") < entity.getPersistentData().getDouble("ll")) {
						entity.getPersistentData().putDouble("llnow", (entity.getPersistentData().getDouble("llnow") + entity.getPersistentData().getDouble("llhf") / 2));
					}
					if (entity.getPersistentData().getDouble("hdznow2") < entity.getPersistentData().getDouble("hdz")) {
						entity.getPersistentData().putDouble("hdznow2", (entity.getPersistentData().getDouble("hdznow2") + entity.getPersistentData().getDouble("hdzhf") / 2));
					}
					entity.getPersistentData().putDouble("smhf23", 0);
					if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlhfs == true) {
						if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2 < (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new WowsModVariables.PlayerVariables())).tlmax) {
							{
								double _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2
										+ (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlhf / 2;
								entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.tlnow2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
						}
					}
					{
						double _setval = entity.getPersistentData().getDouble("healthnow1");
						entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.health3 = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
				});
			}
		}
	}
}
