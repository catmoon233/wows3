package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.wows.network.WowsModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Atset2Procedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("healthnow1") > entity.getPersistentData().getDouble("healthmax") * (1 + entity.getPersistentData().getDouble("smts") / 100)) {
			entity.getPersistentData().putDouble("healthnow1", (entity.getPersistentData().getDouble("healthmax") * (1 + entity.getPersistentData().getDouble("smts") / 100)));
		}
		if (entity.getPersistentData().getDouble("llnow") > entity.getPersistentData().getDouble("ll")) {
			entity.getPersistentData().putDouble("llnow", (entity.getPersistentData().getDouble("ll")));
		}
		if (entity.getPersistentData().getDouble("hdznow2") > entity.getPersistentData().getDouble("hdz")) {
			entity.getPersistentData().putDouble("hdznow2", (entity.getPersistentData().getDouble("hdz")));
		}
		if (entity.getPersistentData().getDouble("llnow") < 0) {
			entity.getPersistentData().putDouble("llnow", 0);
		}
		if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2 < 0) {
			{
				double _setval = 0;
				entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.tlnow2 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2 > (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).tlmax) {
			{
				double _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlmax;
				entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.tlnow2 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlxh < 0) {
			{
				double _setval = 0;
				entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.tlxh = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if (entity.getPersistentData().getDouble("healthnow1") < 0) {
			entity.getPersistentData().putDouble("healthnow1", 0);
			if (entity.getPersistentData().getDouble("swxx") == 1) {
				{
					Entity _ent = entity;
					if (!_ent.level.isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4,
								_ent.getName().getString(), _ent.getDisplayName(), _ent.level.getServer(), _ent), "kill");
					}
				}
			}
		}
	}
}
