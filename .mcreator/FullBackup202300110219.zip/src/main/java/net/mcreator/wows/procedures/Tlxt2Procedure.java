package net.mcreator.wows.procedures;

public class Tlxt2Procedure {
	public static void execute() {
	}
}
