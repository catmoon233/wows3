package net.mcreator.wows.procedures;

public class C1chuProcedure {
	public static void execute() {
	}
}
