package net.mcreator.wows.procedures;

public class BlueslmieShiTiChuShiShengChengShiProcedure {
	public static void execute() {
	}
}
