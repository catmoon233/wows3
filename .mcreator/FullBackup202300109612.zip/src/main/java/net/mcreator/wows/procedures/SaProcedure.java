package net.mcreator.wows.procedures;

public class SaProcedure {
	public static void execute() {
	}
}
