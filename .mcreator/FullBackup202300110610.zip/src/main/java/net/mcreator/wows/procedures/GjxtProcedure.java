package net.mcreator.wows.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.EntityDamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import net.mcreator.wows.network.WowsModVariables;

public class GjxtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double sb1 = 0;
		double sb2 = 0;
		double shz = 0;
		double sb3 = 0;
		double shzb = 0;
		double sb4 = 0;
		double fssh = 0;
		double shzc = 0;
		if (sourceentity.getPersistentData().getDouble("healthnow1") > 0) {
			{
				String _setval = entity.getDisplayName().getString();
				sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.gjst = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
			{
				double _setval = 0;
				sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.zcsh = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
			sb1 = 0;
			sb2 = 0;
			shz = 0;
			shzb = 0;
			shzc = 0;
			sb4 = 0;
			sb1 = Mth.nextInt(RandomSource.create(), 1, 100);
			sb4 = Mth.nextInt(RandomSource.create(), 1, 100);
			sb2 = Mth.nextInt(RandomSource.create(), 1, 100);
			sb3 = Mth.nextInt(RandomSource.create(), 1, 100);
			if (entity.getPersistentData().getDouble("shanbi") > sb1) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(Component.literal("\u4F60\u95EA\u907F\u4E86\u4E00\u6B21\u653B\u51FB"), (false));
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(Component.literal("\u5BF9\u65B9\u95EA\u907F\u4E86\u4F60\u7684\u4E00\u6B21\u653B\u51FB"), (false));
			}
			if (entity.getPersistentData().getDouble("shanbi") <= sb1) {
				shzc = sourceentity.getPersistentData().getDouble("zcdsh") * (sourceentity.getPersistentData().getDouble("gjct") / 100);
				shz = sourceentity.getPersistentData().getDouble("zcdsh") - entity.getPersistentData().getDouble("fy") * (1 - sourceentity.getPersistentData().getDouble("fyct") / 100);
				if (shz <= 0) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1);
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1, false);
						}
					}
				}
				if (shz > 0) {
					shzb = Math.round(shz);
					if (sourceentity.getPersistentData().getDouble("bjjl") > sb2) {
						shzb = Math.round(shzb * (1 + sourceentity.getPersistentData().getDouble("bjbl") / 100));
						if (sourceentity instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(Component.literal("\u66B4\u51FB\u4E86"), (false));
					}
					if (sourceentity.getPersistentData().getDouble("xixue") > sb3) {
						if (sourceentity instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(Component.literal("\u5438\u8840\u4E86"), (false));
						if (sourceentity.getPersistentData().getDouble("healthnow1") < sourceentity.getPersistentData().getDouble("healthmax")) {
							sourceentity.getPersistentData().putDouble("healthnow1", Math.round(sourceentity.getPersistentData().getDouble("healthnow1") + shzb * (sourceentity.getPersistentData().getDouble("xixuebl") / 100)));
						}
					}
					if (entity.getPersistentData().getDouble("fs") > sb4) {
						fssh = Math.round(shzb * (entity.getPersistentData().getDouble("fsbl") / 100) - sourceentity.getPersistentData().getDouble("fy") * (1 - entity.getPersistentData().getDouble("fyct") / 100));
						if (fssh < 0) {
							fssh = 0;
						}
						sourceentity.getPersistentData().putDouble("healthnow1", Math.round(sourceentity.getPersistentData().getDouble("healthnow1") - fssh));
						sourceentity.getPersistentData().putDouble("zcdshb", 0.128715);
						entity.hurt((new EntityDamageSource("wither.player", sourceentity)), 1);
						if (sourceentity instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(Component.literal(("\u5BF9\u65B9\u53CD\u4F24\u4E86\u4F60" + fssh)), (false));
						if (entity instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(Component.literal(("\u4F60\u53CD\u4F24\u4E86\u5BF9\u65B9" + fssh)), (false));
					}
					if (entity.getPersistentData().getDouble("hdznow2") - (shzb + shzc) * (1 - entity.getPersistentData().getDouble("ms") / 100) < 0) {
						entity.getPersistentData().putDouble("healthnow1",
								(entity.getPersistentData().getDouble("healthnow1") + entity.getPersistentData().getDouble("hdznow2") - (shzb + shzc) * (1 - entity.getPersistentData().getDouble("ms") / 100)));
						entity.getPersistentData().putDouble("hdznow2", 0);
					}
					if (entity.getPersistentData().getDouble("hdznow2") - (shzb + shzc) * (1 - entity.getPersistentData().getDouble("ms") / 100) >= 0) {
						entity.getPersistentData().putDouble("hdznow2", (entity.getPersistentData().getDouble("hdznow2") - (shzb + shzc) * (1 - entity.getPersistentData().getDouble("ms") / 100)));
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1, false);
							}
						}
					}
				}
				if (sourceentity.getPersistentData().getDouble("zs") > 0) {
					entity.getPersistentData().putDouble("healthnow1", Math.round(entity.getPersistentData().getDouble("healthnow1") - sourceentity.getPersistentData().getDouble("zs")));
				}
				if (shz < 0) {
					if (entity.getPersistentData().getDouble("hdznow2") - shzc * (1 - entity.getPersistentData().getDouble("ms") / 100) < 0) {
						entity.getPersistentData().putDouble("healthnow1", (entity.getPersistentData().getDouble("healthnow1") + entity.getPersistentData().getDouble("hdznow2") - shzc * (1 - entity.getPersistentData().getDouble("ms") / 100)));
						entity.getPersistentData().putDouble("hdznow2", 0);
					}
					if (entity.getPersistentData().getDouble("hdznow2") - shzc * (1 - entity.getPersistentData().getDouble("ms") / 100) >= 0) {
						entity.getPersistentData().putDouble("hdznow2", (entity.getPersistentData().getDouble("hdznow2") - shzc * (1 - entity.getPersistentData().getDouble("ms") / 100)));
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")), SoundSource.NEUTRAL, 5, 1, false);
							}
						}
					}
				}
			}
			{
				double _setval = Math.round(sourceentity.getPersistentData().getDouble("zs"));
				sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.zcsh2 = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
			{
				double _setval = shzb + shzc;
				sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.zcsh = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
		}
		sourceentity.getPersistentData().putDouble("zcdsh", 0);
	}
}
