package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.mcreator.wows.network.WowsModVariables;
import net.mcreator.wows.WowsMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Smhf2Procedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		Entity entity = event.getEntity();
		if (entity != null && entity.getPersistentData().getDouble("smhf") > 0) {
			if (entity.getPersistentData().getDouble("smhf23") == 0 && entity.getPersistentData().getDouble("smhf2") == 1) {
				entity.getPersistentData().putDouble("smhf23", 1);
				WowsMod.queueServerWork(20, () -> {
					double smhf = entity.getPersistentData().getDouble("smhf");
					if (entity.getPersistentData().getDouble("healthnow1") < entity.getPersistentData().getDouble("healthmax")) {
						entity.getPersistentData().putDouble("healthnow1", entity.getPersistentData().getDouble("healthnow1") + smhf / 2);
						entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.health3 = entity.getPersistentData().getDouble("healthnow1");
							capability.syncPlayerVariables(entity);
						});
					}
					if (entity.getPersistentData().getDouble("llnow") < entity.getPersistentData().getDouble("ll")) {
						entity.getPersistentData().putDouble("llnow", entity.getPersistentData().getDouble("llnow") + entity.getPersistentData().getDouble("llhf") / 2);
					}
					if (entity.getPersistentData().getDouble("hdznow2") < entity.getPersistentData().getDouble("hdz")) {
						entity.getPersistentData().putDouble("hdznow2", entity.getPersistentData().getDouble("hdznow2") + entity.getPersistentData().getDouble("hdzhf") / 2);
					}
					if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlhfs == true
                    && (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2 < (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
                            .orElse(new WowsModVariables.PlayerVariables())).tlmax) {
                        double tlnow2 = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2
                        	+ (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlhf / 2;
                        entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
                            capability.tlnow2 = tlnow2;
                            capability.syncPlayerVariables(entity);
                        });
                    }
					entity.getPersistentData().putDouble("smhf23", 0);
					entity.getPersistentData().putDouble("smhf2", 0);
				});
			}
		}
	}
}