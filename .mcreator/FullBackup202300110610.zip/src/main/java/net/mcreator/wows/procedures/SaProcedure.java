package net.mcreator.wows.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.mcreator.wows.WowsMod;

public class SaProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		WowsMod.queueServerWork(2, () -> {
			entity.getPersistentData().putDouble("nx", (Mth.nextInt(RandomSource.create(), 1, 1000000)));
			entity.getPersistentData().putDouble("ak", Math.round((entity.getPersistentData().getDouble("nx") * 0.25) / 2));
			entity.getPersistentData().putDouble("fy", Math.round(entity.getPersistentData().getDouble("nx") * 0.055));
			entity.getPersistentData().putDouble("healthmax", Math.round(entity.getPersistentData().getDouble("nx") * 0.05 * 30));
			entity.getPersistentData().putDouble("healthnow1", (entity.getPersistentData().getDouble("healthmax")));
			entity.getPersistentData().putDouble("hdz", 10000);
			entity.getPersistentData().putDouble("hdznow2", 10000);
			entity.getPersistentData().putDouble("hdzhf", 400);
			entity.setCustomName(Component.literal((entity.getPersistentData().getDouble("nx") + "\u00A76\u5E74\u566C\u91D1\u767D\u864E")));
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 40, 10));
		});
	}
}
