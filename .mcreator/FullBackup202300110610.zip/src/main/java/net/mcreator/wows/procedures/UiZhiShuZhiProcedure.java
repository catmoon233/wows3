package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.wows.network.WowsModVariables;
import net.mcreator.wows.WowsMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class UiZhiShuZhiProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		execute(null, world, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double a1 = 0;
		double asa1 = 0;
		WowsMod.queueServerWork(1, () -> {
			if (sourceentity.getPersistentData().getDouble("playersx") == 1) {
				{
					double _setval = entity.getPersistentData().getDouble("healthmax");
					sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mbxlmax = _setval;
						capability.syncPlayerVariables(sourceentity);
					});
				}
				{
					double _setval = entity.getPersistentData().getDouble("healthnow1");
					sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mbxl = _setval;
						capability.syncPlayerVariables(sourceentity);
					});
				}
				{
					double _setval = entity.getPersistentData().getDouble("hdz");
					sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mbhd = _setval;
						capability.syncPlayerVariables(sourceentity);
					});
				}
				{
					double _setval = entity.getPersistentData().getDouble("hdznow2");
					sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mbhd2 = _setval;
						capability.syncPlayerVariables(sourceentity);
					});
				}
				if ((sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).mbxl < 0) {
					{
						double _setval = 0;
						sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.mbxl = _setval;
							capability.syncPlayerVariables(sourceentity);
						});
					}
				}
			}
		});
	}
}
