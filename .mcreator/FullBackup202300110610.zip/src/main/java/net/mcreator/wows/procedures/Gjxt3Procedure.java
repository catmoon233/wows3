package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Gjxt3Procedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("playersx") != 1) {
			if (entity.getPersistentData().getDouble("healthmax") <= 0) {
				entity.getPersistentData().putDouble("healthmax", 20);
				entity.getPersistentData().putDouble("healthnow1", 10);
				entity.getPersistentData().putDouble("smhf", 0);
				entity.getPersistentData().putDouble("ms", 0);
				entity.getPersistentData().putDouble("fy", 0);
				entity.getPersistentData().putDouble("zs", 0);
				entity.getPersistentData().putDouble("gjct", 0);
				entity.getPersistentData().putDouble("fyct", 0);
				entity.getPersistentData().putDouble("zcdsh", 0);
				entity.getPersistentData().putDouble("smts", 0);
				entity.getPersistentData().putDouble("fyts", 0);
				entity.getPersistentData().putDouble("gjts", 0);
				entity.getPersistentData().putDouble("fs", 0);
				entity.getPersistentData().putDouble("fsbl", 0);
				entity.getPersistentData().putDouble("hdz", 10);
				entity.getPersistentData().putDouble("hdzhf", 0);
				entity.getPersistentData().putDouble("hdznow2", 10);
				entity.getPersistentData().putDouble("tlmax", 0);
				entity.getPersistentData().putDouble("tlnoow", 0);
				entity.getPersistentData().putDouble("tlhf", 0);
				entity.getPersistentData().putDouble("tlxh", 0);
				entity.getPersistentData().putDouble("zcdshb", 0);
				entity.getPersistentData().putDouble("xixue", 0);
				entity.getPersistentData().putDouble("xixuebl", 0);
				entity.getPersistentData().putDouble("bjbl", 0);
				entity.getPersistentData().putDouble("bjjl", 0);
				entity.getPersistentData().putDouble("shanbi", 0);
			}
		}
		entity.getPersistentData().putDouble("smhf2", 0);
		entity.getPersistentData().putDouble("smhf23", 0);
		entity.getPersistentData().putDouble("tlxh23", 0);
		entity.getPersistentData().putDouble("tlxh2", 0);
		entity.getPersistentData().putDouble("tlhf2", 0);
		entity.getPersistentData().putDouble("tlhf23", 0);
	}
}
