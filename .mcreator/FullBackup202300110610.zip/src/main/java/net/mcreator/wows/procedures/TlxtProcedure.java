package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.wows.network.WowsModVariables;
import net.mcreator.wows.WowsMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class TlxtProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level, event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlxh2) {
			if (entity.getPersistentData().getDouble("tlxh23") == 0) {
				entity.getPersistentData().putDouble("tlxh2", 1);
			}
			if (entity.getPersistentData().getDouble("tlxh2") == 1) {
				entity.getPersistentData().putDouble("tlxh23", 1);
				entity.getPersistentData().putDouble("tlxh2", 0);
				WowsMod.queueServerWork(5, () -> {
					if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new WowsModVariables.PlayerVariables())).tlnow2 > (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2
									- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlxh / 2) {
						{
							double _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlnow2
									- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).tlxh / 1;
							entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.tlnow2 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
					entity.getPersistentData().putDouble("tlxh23", 0);
				});
			}
		}
	}
}
