package net.mcreator.wows.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.mcreator.wows.network.WowsModVariables;

public class SaProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("nx", (Mth.nextInt(RandomSource.create(), 1, 1000000)));
		{
			double _setval = entity.getPersistentData().getDouble("nx") * 0.075;
			entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.fy = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		{
			double _setval = (entity.getPersistentData().getDouble("nx") * 0.001) / 10;
			entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.ak = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS)
				.setBaseValue((entity.getPersistentData().getDouble("nx") * 0.5));
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)
				.setBaseValue((entity.getPersistentData().getDouble("nx") * 0.055));
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
				.setBaseValue((entity.getPersistentData().getDouble("nx") * 0.5));
		entity.setCustomName(Component.literal((entity.getPersistentData().getDouble("nx") + "\u00A76\u5E74\u566C\u91D1\u767D\u864E")));
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 40, 10));
	}
}
