package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.mcreator.wows.network.WowsModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class FyxtProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double ancvko = 0;
		double sjs = 0;
		double cs = 0;
		double cs2 = 0;
		double sjs2 = 0;
		sjs = Mth.nextInt(RandomSource.create(), (int) (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).bjjl, 100);
		sjs2 = Mth.nextInt(RandomSource.create(), (int) (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).shanbi, 100);
		if (Mth.nextInt(RandomSource.create(), (int) (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).shanbi, 100) != 100) {
			if ((sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).ak
					/ 10 > (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new WowsModVariables.PlayerVariables())).fy / 10) {
				if (sjs == 100) {
					entity.hurt((new DamageSource("generic")),
							(float) (((sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new WowsModVariables.PlayerVariables())).ak / 10
									- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new WowsModVariables.PlayerVariables())).fy / 10)
									* (1 + (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new WowsModVariables.PlayerVariables())).bjbl)));
					if (sourceentity instanceof Player _player && !_player.level.isClientSide())
						_player.displayClientMessage(Component.literal("\u66B4\u51FB\u4E86"), (false));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)
								- (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new WowsModVariables.PlayerVariables())).zs));
				}
				if (sjs != 100) {
					entity.hurt((new DamageSource("generic")),
							(float) ((sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new WowsModVariables.PlayerVariables())).ak / 10
									- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new WowsModVariables.PlayerVariables())).fy / 10));
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)
								- (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new WowsModVariables.PlayerVariables())).zs));
				}
			}
			if ((sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).ak
					/ 10 <= (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new WowsModVariables.PlayerVariables())).fy / 10) {
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - (sourceentity
							.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).zs));
			}
		}
		if (Mth.nextInt(RandomSource.create(), (int) (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).shanbi, 100) == 100) {
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(Component.literal("\u95EA\u907F\u4E86"), (false));
		}
	}
}
