package net.mcreator.wows.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.wows.network.WowsModVariables;

public class LevernowlcProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new WowsModVariables.PlayerVariables())).levernow > (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new WowsModVariables.PlayerVariables())).leverup) {
			{
				double _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new WowsModVariables.PlayerVariables())).lever + 1;
				entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.lever = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new WowsModVariables.PlayerVariables())).levernow
						- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new WowsModVariables.PlayerVariables())).leverup;
				entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.levernow = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
