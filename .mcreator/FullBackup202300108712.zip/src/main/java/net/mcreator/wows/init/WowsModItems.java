
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wows.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.wows.item.MujianItem;
import net.mcreator.wows.item.LmglItem;
import net.mcreator.wows.item.Lmgl2Item;
import net.mcreator.wows.item.Jb1Item;
import net.mcreator.wows.WowsMod;

public class WowsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WowsMod.MODID);
	public static final RegistryObject<Item> JB_1 = REGISTRY.register("jb_1", () -> new Jb1Item());
	public static final RegistryObject<Item> UIS_SPAWN_EGG = REGISTRY.register("uis_spawn_egg", () -> new ForgeSpawnEggItem(WowsModEntities.UIS, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BLUESLMIE_SPAWN_EGG = REGISTRY.register("blueslmie_spawn_egg", () -> new ForgeSpawnEggItem(WowsModEntities.BLUESLMIE, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> LMGL = REGISTRY.register("lmgl", () -> new LmglItem());
	public static final RegistryObject<Item> MUJIAN = REGISTRY.register("mujian", () -> new MujianItem());
	public static final RegistryObject<Item> LMGL_2 = REGISTRY.register("lmgl_2", () -> new Lmgl2Item());
}
