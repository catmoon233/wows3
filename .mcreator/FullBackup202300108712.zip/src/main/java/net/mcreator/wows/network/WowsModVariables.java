package net.mcreator.wows.network;

import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.client.Minecraft;

import net.mcreator.wows.WowsMod;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WowsModVariables {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		WowsMod.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer, PlayerVariablesSyncMessage::new, PlayerVariablesSyncMessage::handler);
	}

	@SubscribeEvent
	public static void init(RegisterCapabilitiesEvent event) {
		event.register(PlayerVariables.class);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void clonePlayer(PlayerEvent.Clone event) {
			event.getOriginal().revive();
			PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
			PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
			clone.ak = original.ak;
			clone.health = original.health;
			clone.health2 = original.health2;
			clone.lever = original.lever;
			clone.leverup = original.leverup;
			clone.zl = original.zl;
			clone.fy = original.fy;
			clone.hj = original.hj;
			clone.atafter = original.atafter;
			clone.levernow = original.levernow;
			clone.nx = original.nx;
			clone.liliang = original.liliang;
			clone.tipo = original.tipo;
			clone.minjie = original.minjie;
			clone.zdl = original.zdl;
			clone.bjjl = original.bjjl;
			clone.bjbl = original.bjbl;
			clone.zs = original.zs;
			clone.shanbi = original.shanbi;
			clone.cssz = original.cssz;
			clone.lwdl = original.lwdl;
			clone.zhdl = original.zhdl;
			clone.dl = original.dl;
			clone.start = original.start;
			clone.xz1 = original.xz1;
			clone.xz2 = original.xz2;
			clone.xz3 = original.xz3;
			clone.wd = original.wd;
			clone.lw1 = original.lw1;
			clone.lw2 = original.lw2;
			clone.lwsf = original.lwsf;
			clone.lever2 = original.lever2;
			clone.levernow2 = original.levernow2;
			clone.leverup2 = original.leverup2;
			clone.xixue = original.xixue;
			clone.xixuebl = original.xixuebl;
			if (!event.isWasDeath()) {
				clone.lwsf2 = original.lwsf2;
			}
		}
	}

	public static final Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = CapabilityManager.get(new CapabilityToken<PlayerVariables>() {
	});

	@Mod.EventBusSubscriber
	private static class PlayerVariablesProvider implements ICapabilitySerializable<Tag> {
		@SubscribeEvent
		public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
			if (event.getObject() instanceof Player && !(event.getObject() instanceof FakePlayer))
				event.addCapability(new ResourceLocation("wows", "player_variables"), new PlayerVariablesProvider());
		}

		private final PlayerVariables playerVariables = new PlayerVariables();
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(() -> playerVariables);

		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public Tag serializeNBT() {
			return playerVariables.writeNBT();
		}

		@Override
		public void deserializeNBT(Tag nbt) {
			playerVariables.readNBT(nbt);
		}
	}

	public static class PlayerVariables {
		public double ak = 1.0;
		public double health = 100.0;
		public double health2 = 0.0;
		public double lever = 0;
		public double leverup = 0;
		public double zl = 0;
		public double fy = 0.0;
		public double hj = 0;
		public double atafter = 0;
		public double levernow = 0;
		public double nx = 0;
		public double liliang = 0;
		public double tipo = 0;
		public double minjie = 0;
		public double zdl = 0;
		public double bjjl = 0;
		public double bjbl = 0;
		public double zs = 0;
		public double shanbi = 0.0;
		public double cssz = 0;
		public double lwdl = 0;
		public double zhdl = 0.0;
		public String dl = "\"\"";
		public double start = 0;
		public double xz1 = 0;
		public double xz2 = 0;
		public double xz3 = 0;
		public String wd = "w";
		public ItemStack lw1 = ItemStack.EMPTY;
		public ItemStack lw2 = ItemStack.EMPTY;
		public double lwsf = 0;
		public double lwsf2 = 0;
		public double lever2 = 0;
		public double levernow2 = 0;
		public double leverup2 = 0;
		public double xixue = 0;
		public double xixuebl = 0;

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayer serverPlayer)
				WowsMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer), new PlayerVariablesSyncMessage(this));
		}

		public Tag writeNBT() {
			CompoundTag nbt = new CompoundTag();
			nbt.putDouble("ak", ak);
			nbt.putDouble("health", health);
			nbt.putDouble("health2", health2);
			nbt.putDouble("lever", lever);
			nbt.putDouble("leverup", leverup);
			nbt.putDouble("zl", zl);
			nbt.putDouble("fy", fy);
			nbt.putDouble("hj", hj);
			nbt.putDouble("atafter", atafter);
			nbt.putDouble("levernow", levernow);
			nbt.putDouble("nx", nx);
			nbt.putDouble("liliang", liliang);
			nbt.putDouble("tipo", tipo);
			nbt.putDouble("minjie", minjie);
			nbt.putDouble("zdl", zdl);
			nbt.putDouble("bjjl", bjjl);
			nbt.putDouble("bjbl", bjbl);
			nbt.putDouble("zs", zs);
			nbt.putDouble("shanbi", shanbi);
			nbt.putDouble("cssz", cssz);
			nbt.putDouble("lwdl", lwdl);
			nbt.putDouble("zhdl", zhdl);
			nbt.putString("dl", dl);
			nbt.putDouble("start", start);
			nbt.putDouble("xz1", xz1);
			nbt.putDouble("xz2", xz2);
			nbt.putDouble("xz3", xz3);
			nbt.putString("wd", wd);
			nbt.put("lw1", lw1.save(new CompoundTag()));
			nbt.put("lw2", lw2.save(new CompoundTag()));
			nbt.putDouble("lwsf", lwsf);
			nbt.putDouble("lwsf2", lwsf2);
			nbt.putDouble("lever2", lever2);
			nbt.putDouble("levernow2", levernow2);
			nbt.putDouble("leverup2", leverup2);
			nbt.putDouble("xixue", xixue);
			nbt.putDouble("xixuebl", xixuebl);
			return nbt;
		}

		public void readNBT(Tag Tag) {
			CompoundTag nbt = (CompoundTag) Tag;
			ak = nbt.getDouble("ak");
			health = nbt.getDouble("health");
			health2 = nbt.getDouble("health2");
			lever = nbt.getDouble("lever");
			leverup = nbt.getDouble("leverup");
			zl = nbt.getDouble("zl");
			fy = nbt.getDouble("fy");
			hj = nbt.getDouble("hj");
			atafter = nbt.getDouble("atafter");
			levernow = nbt.getDouble("levernow");
			nx = nbt.getDouble("nx");
			liliang = nbt.getDouble("liliang");
			tipo = nbt.getDouble("tipo");
			minjie = nbt.getDouble("minjie");
			zdl = nbt.getDouble("zdl");
			bjjl = nbt.getDouble("bjjl");
			bjbl = nbt.getDouble("bjbl");
			zs = nbt.getDouble("zs");
			shanbi = nbt.getDouble("shanbi");
			cssz = nbt.getDouble("cssz");
			lwdl = nbt.getDouble("lwdl");
			zhdl = nbt.getDouble("zhdl");
			dl = nbt.getString("dl");
			start = nbt.getDouble("start");
			xz1 = nbt.getDouble("xz1");
			xz2 = nbt.getDouble("xz2");
			xz3 = nbt.getDouble("xz3");
			wd = nbt.getString("wd");
			lw1 = ItemStack.of(nbt.getCompound("lw1"));
			lw2 = ItemStack.of(nbt.getCompound("lw2"));
			lwsf = nbt.getDouble("lwsf");
			lwsf2 = nbt.getDouble("lwsf2");
			lever2 = nbt.getDouble("lever2");
			levernow2 = nbt.getDouble("levernow2");
			leverup2 = nbt.getDouble("leverup2");
			xixue = nbt.getDouble("xixue");
			xixuebl = nbt.getDouble("xixuebl");
		}
	}

	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;

		public PlayerVariablesSyncMessage(FriendlyByteBuf buffer) {
			this.data = new PlayerVariables();
			this.data.readNBT(buffer.readNbt());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeNbt((CompoundTag) message.data.writeNBT());
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
					variables.ak = message.data.ak;
					variables.health = message.data.health;
					variables.health2 = message.data.health2;
					variables.lever = message.data.lever;
					variables.leverup = message.data.leverup;
					variables.zl = message.data.zl;
					variables.fy = message.data.fy;
					variables.hj = message.data.hj;
					variables.atafter = message.data.atafter;
					variables.levernow = message.data.levernow;
					variables.nx = message.data.nx;
					variables.liliang = message.data.liliang;
					variables.tipo = message.data.tipo;
					variables.minjie = message.data.minjie;
					variables.zdl = message.data.zdl;
					variables.bjjl = message.data.bjjl;
					variables.bjbl = message.data.bjbl;
					variables.zs = message.data.zs;
					variables.shanbi = message.data.shanbi;
					variables.cssz = message.data.cssz;
					variables.lwdl = message.data.lwdl;
					variables.zhdl = message.data.zhdl;
					variables.dl = message.data.dl;
					variables.start = message.data.start;
					variables.xz1 = message.data.xz1;
					variables.xz2 = message.data.xz2;
					variables.xz3 = message.data.xz3;
					variables.wd = message.data.wd;
					variables.lw1 = message.data.lw1;
					variables.lw2 = message.data.lw2;
					variables.lwsf = message.data.lwsf;
					variables.lwsf2 = message.data.lwsf2;
					variables.lever2 = message.data.lever2;
					variables.levernow2 = message.data.levernow2;
					variables.leverup2 = message.data.leverup2;
					variables.xixue = message.data.xixue;
					variables.xixuebl = message.data.xixuebl;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
