package net.mcreator.wows.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.EntityDamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.wows.network.WowsModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class Fyxt2Procedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double sf = 0;
		double sf1 = 0;
		double sjs = 0;
		double aamount = 0;
		double sjs2 = 0;
		double bamount = 0;
		aamount = 0;
		bamount = 0;
		sjs = Mth.nextInt(RandomSource.create(), 1, 100);
		if (sjs <= (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).shanbi) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
		}
		if (sjs > (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).shanbi) {
			if (sf1 == 0) {
				if (sf == 1) {
					sf = 0;
				}
			}
			sf1 = 0;
			if (sf1 == 0) {
				aamount = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).ak
						- (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).fy;
				if (aamount > 0) {
					sjs2 = Mth.nextInt(RandomSource.create(), 1, 100);
					if (sjs2 <= (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).bjjl) {
						bamount = aamount * (1 + (sourceentity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).bjbl);
					}
				}
				if (bamount > 0) {
					entity.hurt((new EntityDamageSource("generic.player", sourceentity)), (float) bamount);
				}
				if (bamount == 0) {
					entity.hurt((new EntityDamageSource("generic.player", sourceentity)), (float) aamount);
				}
				sf1 = 1;
				sf = 1;
			}
		}
	}
}
