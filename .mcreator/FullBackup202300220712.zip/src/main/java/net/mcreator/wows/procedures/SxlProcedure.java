package net.mcreator.wows.procedures;

public class SxlProcedure {
	public static void execute() {
	}
}
