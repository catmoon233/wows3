package net.mcreator.wows.procedures;

public class LwjclcProcedure {
	public static void execute() {
		double sj = 0;
		double sj1 = 0;
	}
}
