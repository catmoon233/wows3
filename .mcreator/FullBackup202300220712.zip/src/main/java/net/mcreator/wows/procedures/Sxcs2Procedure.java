package net.mcreator.wows.procedures;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.wows.network.WowsModVariables;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

@Mod.EventBusSubscriber
public class Sxcs2Procedure {
	@SubscribeEvent
	public static void onPlayerRespawned(PlayerEvent.PlayerRespawnEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		com.google.gson.JsonObject dqdsx = new com.google.gson.JsonObject();
		File dqsx = new File("");
		{
			String _setval = (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).playerhp2 + "/"
					+ (entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WowsModVariables.PlayerVariables())).playermaxhp2;
			entity.getCapability(WowsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.xueliangwb = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		dqsx = new File((FMLPaths.GAMEDIR.get().toString() + "/config/xlzj"), File.separator + (entity.getDisplayName().getString() + "sx.json"));
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(dqsx));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				dqdsx = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("healthmax");
					if (_so == null)
						_so = _sc.addObjective("healthmax", ObjectiveCriteria.DUMMY, Component.literal("healthmax"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("healthmax").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("healthnow");
					if (_so == null)
						_so = _sc.addObjective("healthnow", ObjectiveCriteria.DUMMY, Component.literal("healthnow"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore(100);
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("smhf");
					if (_so == null)
						_so = _sc.addObjective("smhf", ObjectiveCriteria.DUMMY, Component.literal("smhf"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("smhf").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("zs");
					if (_so == null)
						_so = _sc.addObjective("zs", ObjectiveCriteria.DUMMY, Component.literal("zs"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("zs").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("ms");
					if (_so == null)
						_so = _sc.addObjective("ms", ObjectiveCriteria.DUMMY, Component.literal("ms"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("ms").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("ak");
					if (_so == null)
						_so = _sc.addObjective("ak", ObjectiveCriteria.DUMMY, Component.literal("ak"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("ak").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("fy");
					if (_so == null)
						_so = _sc.addObjective("fy", ObjectiveCriteria.DUMMY, Component.literal("fy"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("fy").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("bjbl");
					if (_so == null)
						_so = _sc.addObjective("bjbl", ObjectiveCriteria.DUMMY, Component.literal("bjbl"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("bjbl").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("shanbi");
					if (_so == null)
						_so = _sc.addObjective("shanbi", ObjectiveCriteria.DUMMY, Component.literal("shanbi"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("shanbi").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("bjjl");
					if (_so == null)
						_so = _sc.addObjective("bjjl", ObjectiveCriteria.DUMMY, Component.literal("bjjl"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("bjjl").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("xixue");
					if (_so == null)
						_so = _sc.addObjective("xixue", ObjectiveCriteria.DUMMY, Component.literal("xixue"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("xixue").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("xixuebl");
					if (_so == null)
						_so = _sc.addObjective("xixuebl", ObjectiveCriteria.DUMMY, Component.literal("xixuebl"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("xixuebl").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("gjct");
					if (_so == null)
						_so = _sc.addObjective("gjct", ObjectiveCriteria.DUMMY, Component.literal("gjct"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("gjct").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("fyct");
					if (_so == null)
						_so = _sc.addObjective("fyct", ObjectiveCriteria.DUMMY, Component.literal("fyct"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("fyct").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("smts");
					if (_so == null)
						_so = _sc.addObjective("smts", ObjectiveCriteria.DUMMY, Component.literal("smts"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("smts").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("fyts");
					if (_so == null)
						_so = _sc.addObjective("fyts", ObjectiveCriteria.DUMMY, Component.literal("fyts"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("fyts").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("gjts");
					if (_so == null)
						_so = _sc.addObjective("gjts", ObjectiveCriteria.DUMMY, Component.literal("gjts"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("gjts").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("fs");
					if (_so == null)
						_so = _sc.addObjective("fs", ObjectiveCriteria.DUMMY, Component.literal("fs"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("fs").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("fsbl");
					if (_so == null)
						_so = _sc.addObjective("fsbl", ObjectiveCriteria.DUMMY, Component.literal("fsbl"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("fsbl").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("ll");
					if (_so == null)
						_so = _sc.addObjective("ll", ObjectiveCriteria.DUMMY, Component.literal("ll"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("ll").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("llhf");
					if (_so == null)
						_so = _sc.addObjective("llhf", ObjectiveCriteria.DUMMY, Component.literal("llhf"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("llhf").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("hdz");
					if (_so == null)
						_so = _sc.addObjective("hdz", ObjectiveCriteria.DUMMY, Component.literal("hdz"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("hdz").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("hdzhf");
					if (_so == null)
						_so = _sc.addObjective("hdzhf", ObjectiveCriteria.DUMMY, Component.literal("hdzhf"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("hdzhf").getAsDouble());
				}
				{
					Entity _ent = entity;
					Scoreboard _sc = _ent.getLevel().getScoreboard();
					Objective _so = _sc.getObjective("playersx");
					if (_so == null)
						_so = _sc.addObjective("playersx", ObjectiveCriteria.DUMMY, Component.literal("playersx"), ObjectiveCriteria.RenderType.INTEGER);
					_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).setScore((int) dqdsx.get("playersx").getAsDouble());
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
